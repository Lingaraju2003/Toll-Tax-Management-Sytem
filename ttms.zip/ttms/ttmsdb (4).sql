-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2024 at 02:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ttmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `UserName` varchar(50) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'Ashwin', 'Ashwin01', 8660362489, 'ashwin@gmail.com', 'Ashwin', '2024-03-01 15:37:44'),
(2, 'abc', 'abc', 123, '123@gmail.com', '123', '2024-03-01 16:13:23'),
(50, 'Kavana', '', 8552, '8552@gmail.com', '8552', '2024-03-08 03:57:26'),
(51, 'Ashwin', '', 5477, 'Asd@gmail.com', '456', '2024-03-08 04:31:56');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `ID` int(10) NOT NULL,
  `VehicleCat` varchar(120) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`ID`, `VehicleCat`, `CreationDate`) VALUES
(0, '6 Wheeler', NULL),
(102, '10 Wheeler', NULL),
(201, '3 wheeler', '0000-00-00 00:00:00'),
(301, '4 wheeler', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblpass`
--

CREATE TABLE `tblpass` (
  `ID` int(10) NOT NULL,
  `Passid` varchar(120) DEFAULT NULL,
  `VehicleCat` varchar(120) DEFAULT NULL,
  `VehicleName` varchar(120) DEFAULT NULL,
  `RegNumber` char(50) DEFAULT NULL,
  `Validityfrom` varchar(120) DEFAULT NULL,
  `ValidityTo` varchar(120) DEFAULT NULL,
  `AppName` varchar(120) DEFAULT NULL,
  `AppGender` varchar(50) DEFAULT NULL,
  `AppAge` int(20) DEFAULT NULL,
  `AppAdd` mediumtext DEFAULT NULL,
  `PassCost` varchar(50) DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblpass`
--

INSERT INTO `tblpass` (`ID`, `Passid`, `VehicleCat`, `VehicleName`, `RegNumber`, `Validityfrom`, `ValidityTo`, `AppName`, `AppGender`, `AppAge`, `AppAdd`, `PassCost`, `CreationDate`) VALUES
(101, '716115535', '10 Wheeler', 'BHARATH BENZ', 'KA 13 M 2345', '2024-02-10', '2024-03-10', 'RAJU', 'Male', 25, 'BENGALARU', '300', '2024-03-14 05:40:01'),
(102, '901638177', '6 Wheeler', 'lorry', 'KA 13 M7896', '2024-03-15', '2024-04-15', 'MANJA', 'Female', 45, 'MANGALURU\r\n', '350', '2024-03-15 01:33:41'),
(103, '192358326', '3 wheeler', 'AUTO', 'KA 12 R 6178', '2024-04-16', '2024-05-15', 'PAVAN', 'Male', 33, 'MYSURU', '300', '2024-03-15 01:36:29'),
(301, '728319725', '4 wheeler', 'Ape', 'AUS-301', '2024-03-20', '2025-03-19', 'Bhoomika', 'Female', 99, 'Kerlapura', '990', '0000-00-00 00:00:00'),
(401, '202457365', '4 wheeler', 'Ferrari', 'CAM-010', '2001-01-01', '2002-01-01', 'Ashwin', 'Male', 20, 'Manglore', '800', '2024-03-08 07:20:46');

-- --------------------------------------------------------

--
-- Table structure for table `tblreceipt`
--

CREATE TABLE `tblreceipt` (
  `Staffid` int(10) DEFAULT NULL,
  `LaneNumber` varchar(120) NOT NULL,
  `Receiptid` varchar(50) DEFAULT NULL,
  `VehicleCat` varchar(120) DEFAULT NULL,
  `VehicleName` varchar(150) DEFAULT NULL,
  `OwnerName` varchar(120) DEFAULT NULL,
  `VehicleNumber` varchar(120) DEFAULT NULL,
  `EnterVehiclecity` varchar(120) DEFAULT NULL,
  `Trip` varchar(120) DEFAULT NULL,
  `Cost` varchar(120) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblreceipt`
--

INSERT INTO `tblreceipt` (`Staffid`, `LaneNumber`, `Receiptid`, `VehicleCat`, `VehicleName`, `OwnerName`, `VehicleNumber`, `EnterVehiclecity`, `Trip`, `Cost`, `CreationDate`, `ID`) VALUES
(101, 'Lane1', '324219518', '4 wheeler', 'Porse 911', 'Ashwin', 'DUB 001', 'Dubai', 'Two Way Trip', '$20000', NULL, 0),
(89, '2', '487', '2Wheller', 'Maruthi', 'fmy', '4479', 'Hassan', 'on way', '54', '2024-03-04 12:42:02', 0),
(101, 'Lane4', '758906882', '4 wheeler', '55', 'jj', '54', 'mk', 'Two Way Trip', '545', '2024-03-08 07:42:03', 0),
(101, 'Lane2', '221318919', '10 Wheeler', 'BHARATH BENZ', 'RAJU', 'KA 13 M 2345', 'BENGALARU', 'Two Way Trip', '250', '2024-03-14 05:42:51', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblstaff`
--

CREATE TABLE `tblstaff` (
  `ID` int(10) NOT NULL,
  `StaffID` varchar(50) DEFAULT NULL,
  `StaffName` varchar(120) DEFAULT NULL,
  `StaffMobilenumber` bigint(10) DEFAULT NULL,
  `StaffEmail` varchar(120) DEFAULT NULL,
  `StaffGender` varchar(20) DEFAULT NULL,
  `StaffAddress` varchar(200) DEFAULT NULL,
  `StaffDOB` varchar(200) DEFAULT NULL,
  `StaffPassword` varchar(120) DEFAULT NULL,
  `JoiningDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblstaff`
--

INSERT INTO `tblstaff` (`ID`, `StaffID`, `StaffName`, `StaffMobilenumber`, `StaffEmail`, `StaffGender`, `StaffAddress`, `StaffDOB`, `StaffPassword`, `JoiningDate`) VALUES
(0, '195270200', 'Meghana', 456789456, 'meghana@gmail.com', 'Female', 'Hassan', '2003-09-25', 'meghana123', '2024-03-02 13:22:30'),
(11, '387099487', 'asw', 789, '789@gmail.com', 'Male', 'Manglore', '2024-03-30', '789', '2024-03-08 06:47:13'),
(101, 's1', 'Ashu', 123, '123@gmail.com', 'M', 'Ark', '26-06-2003', 'asd', '2024-03-02 12:11:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpass`
--
ALTER TABLE `tblpass`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblstaff`
--
ALTER TABLE `tblstaff`
  ADD PRIMARY KEY (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
