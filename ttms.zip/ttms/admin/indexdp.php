<?php
// session_start();
// error_reporting(0);
 include('includes/dbconnection.php');
// echo "Hello1";

if(isset($_POST['login']))
  {
    $adminuser=$_POST['username'];
    $password=$_POST['password'];
    $query = "select * from tbladmin where UserName='$adminuser'";
    $result=mysqli_query($con,$query);
    $ret=mysqli_fetch_array($result, MYSQLI_ASSOC);
    // echo "Hello2";
    // echo $ret["Password"];
    if($ret["Password"] != $password){
      $msg="Invalid Details.";
    }
    else{
        header('location: dashboard.php');
    }
    // if($ret["Password"] == $password){
    //     // echo $ret["Password"];
    //     header('location: ./dashboard.php');
    // }
    // if($ret>0){
    //   $_SESSION['ttmsaid']=$ret['ID'];
    //  header('location:dashboard.php');
    // }
    // else{
    //     $msg="Invalid Details.";
    // }
}
// echo "Hello3";
  ?>