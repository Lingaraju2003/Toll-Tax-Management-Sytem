
<!DOCTYPE HTML>
<html>
<head>
<title>Toll Tax Management System || SignUp Page</title>

<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if(isset($_POST['signUp']))
  {
    $id1=$_POST['id1'];
    $adminName=$_POST['aname'];
    $adminuser=$_POST['username'];
    $mobnum=$_POST['mobnum'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $cdate = date('Y-m-d H:i:s');
    $query = "insert into tbladmin(ID, AdminName, UserName, MobileNumber, Email, Password, AdminRegdate) values('$id1', '$adminName', '$adminUser', '$mobnum', '$email', '$password', '$cdate')";
    $result=mysqli_query($con,$query);
    if($result){
        header('location: dashboard.php');
    }
    else{
        $msg="Creation failed";
    }
}
  ?>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!----webfonts--->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
<!---//webfonts--->  
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
</head>
<body id="login">
  <div class="login-logo">
    <a href="index.php"><strong style="color: black">Toll Tax Management System</strong></a>
  </div>
  <h2 class="form-heading">SignUp</h2>
  <div class="app-cam">
    <!-- <form action="signUpdp.php" method="POST"> -->
	  <form method="post">
		<p style="font-size:16px; color:red" align="center"> <?php if($msg){
    echo $msg;
  }  ?> </p>
    <input type="text" class="text" name="id1" placeholder="ID" required="true">
    <input type="text" class="text" name="aname" placeholder="Admin Name" required="true">
    <input type="text" class="text" name="username" placeholder="Username" required="true">
    <input type="text" class="text" name="mobnum" placeholder="Mobile number" required="true">
    <input type="text" class="text" name="email" placeholder="Email" required="true">
    <input type="password" name="password" class="text" placeholder="Password" required="true">
		<div class="submit"><input type="submit"  value="Sign Up" name="signUp"></div>
        <p class="new_left"><p>Already have an account?<a href="index.php"> Click here</a></p></p>
		
		<ul class="new">
			<!-- <li class="new_left"><p><a href="forgot-password.php">Forgot Password ?</a></p></li> -->
      <li class="new_right"><p><a href="../index.php">Back to Home</a></p></li>
			</li>
			<div class="clearfix"></div>
		</ul>
	</form>
  <!-- </form> -->
  </div>
   <?php include_once('includes/footer.php');?>
</body>
</html>
